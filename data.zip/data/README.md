# Dane przykładowe

W projekcie umieszczono próbkę `avocado.csv` (Kaggle) z danymi o cenach awokado.
Użyj jej z poziomu aplikacji wybierając **Użyj zestawu przykładowego (avocado)**.
