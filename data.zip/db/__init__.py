"""
Moduł bazy danych TMIV - SQLite tracker i utilities.
"""