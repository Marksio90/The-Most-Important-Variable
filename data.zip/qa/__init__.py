"""
Quality Assurance - testy aplikacji.
"""