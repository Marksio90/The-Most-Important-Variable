"""
Testy jednostkowe i integracyjne.
"""