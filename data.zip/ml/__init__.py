"""
Moduł ML - modele, trening, feature engineering.
"""