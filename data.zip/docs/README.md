# TMIV v4.2
Nowości: LLM key w sidebarze, naprawa NaN w target, SHAP beeswarm/dependence, stabilny eksport i historia.